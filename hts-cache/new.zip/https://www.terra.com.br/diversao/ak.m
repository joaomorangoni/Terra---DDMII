<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Terra Networks S.A.</title>
<meta http-equiv="Refresh" content="0;url=https://www.terra.com.br/busca/?curl=http://www.terra.com.br/diversao/ak.m" />
</head>
</html>
